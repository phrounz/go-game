A Compo for Ludum Dare 44, made by volatile-dove
https://ldjam.com/events/ludum-dare/44/$147173
