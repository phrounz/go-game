#!/bin/sh
./ludumdare44 -fullscreen
